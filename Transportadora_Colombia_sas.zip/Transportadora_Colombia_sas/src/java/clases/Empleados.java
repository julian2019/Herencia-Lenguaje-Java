/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author PAOLA
 */

public abstract class Empleados implements Calculable {

    protected char cargo;
    private int cedula;
    protected char nombre;
    protected char contraseña;
    protected char direccion;
    private int telefono;
    

    public Empleados() {
    }

    public Empleados(int cedula, char cargo, char nombre, char contraseña, char direccion, int telefono) {
        this.cedula = cedula;
        this.cargo = cargo;
        this.nombre = nombre;
        this.contraseña = contraseña;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    public abstract String mostrarProducto();

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(char cargo) {
        this.cargo = cargo;
    }

    public double getNombre() {
        return nombre;
    }

    public void setNombre(char nombre) {
        this.nombre = nombre;
    }

    public int getContraseña() {
        return contraseña;
    }

    public void setContraseña(int contraseña) {
        this.contraseña = contraseña;
    }

    public int getDireccion() {
        return direccion;
    }

    public void setDireccion(int direccion) {
        this.direccion = direccion;
    }

}

