package clases;

public class usuarios {
    
private int cedula;
    private String nombre;
    private Factura[] arrFactura;

    public Cliente(int cedula, String nombre) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.arrFactura = arrFactura;
    }

    public String mostrarCliente(Cliente cliente) {
        String mostrarCliente = "Informacion del Cliente" + "\n"
                + "Nombre:  " + cliente.getNombre() + "    Cédula:  " + cliente.getCedula();

        return mostrarCliente;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Factura[] getArrFactura() {
        return arrFactura;
    }

    public void setArrFactura(Factura[] arrFactura) {
        this.arrFactura = arrFactura;
    }

}

