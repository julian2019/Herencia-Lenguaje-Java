package clases;


public class factura {
    
 private Cliente persona;
    public Producto[] arrProductos;
    protected int maxiProducto;

    public Factura(Cliente persona, int maxiProducto, Producto[] arrProducto) {
        this.persona = persona;
        this.maxiProducto = maxiProducto;
        arrProductos = arrProducto;
       
    }

    public void agregarProducto(Producto producto, int posicion) {
        arrProductos[posicion] = producto;
    }

    public void mostrarFactura() {
        System.out.print("\n" + persona.mostrarCliente(persona));
        System.out.print("\n" + "Productos " + "\n");
        System.out.print("\n" + "Cantidad " + "Codigo " + " Producto " + " Precio " + " Descuento " + " Total " + "\n");
        Producto miProducto = null;
        for (int i = 0; i < arrProductos.length; i++) {
            if (arrProductos[i] instanceof SinOferta) {
                miProducto = new SinOferta();
                miProducto = arrProductos[i];
                System.out.println("" + ((SinOferta) miProducto).mostrarProducto((SinOferta) miProducto));
            }
            if (arrProductos[i] instanceof EnOferta) {
                miProducto = new EnOferta();
                miProducto = arrProductos[i];
                System.out.println("" + ((EnOferta) miProducto).mostrarProducto((EnOferta) miProducto));
            }
        }
    }

    public String calcular(Producto producto) {
        float totalFactura = 0;
        int cantidadProducto = 0;
        String mostrar = "";
        Producto miProducto = null;
        for (int i = 0; i < arrProductos.length; i++) {
            if (arrProductos[i] instanceof SinOferta) {
                miProducto = new SinOferta();
                miProducto = arrProductos[i];
                totalFactura += ((SinOferta) miProducto).calcularPrecioProducto();
                cantidadProducto += ((SinOferta) miProducto).getCantidad();
            }
            if (arrProductos[i] instanceof EnOferta) {
                miProducto = new EnOferta();
                miProducto = arrProductos[i];
                totalFactura += ((EnOferta) miProducto).calcularPrecioProducto();
                cantidadProducto += ((EnOferta) miProducto).getCantidad();
            }
        }
        mostrar = "La cantidad de Articulos: " + cantidadProducto + " El Total a Cancelar: " + totalFactura + "\n";
        return mostrar;
    }

    public Cliente getPersona() {
        return persona;
    }

    public void setPersona(Cliente persona) {
        this.persona = persona;
    }

    public Producto[] getArrProductos() {
        return arrProductos;
    }

    public void setArrProductos(Producto[] arrProductos) {
        this.arrProductos = arrProductos;
    }

    public int getMaxiProducto() {
        return maxiProducto;
    }

    public void setMaxiProducto(int maxiProducto) {
        this.maxiProducto = maxiProducto;
    }

}

